/** Automatically generated file. DO NOT MODIFY */
package com.greenfoxmedia.greenfoxmedia;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}